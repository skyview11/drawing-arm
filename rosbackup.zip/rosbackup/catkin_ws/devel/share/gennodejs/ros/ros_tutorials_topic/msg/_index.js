
"use strict";

let MsgTutorial = require('./MsgTutorial.js');

module.exports = {
  MsgTutorial: MsgTutorial,
};
