#!/usr/bin/env python
from __future__ import print_function

import roslib
roslib.load_manifest('cv_bridge_tutorial')
import sys
import rospy
import cv2
import os
import yaml
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Pose


class image_converter:

    def __init__(self):
        self.pose_pub = rospy.Publisher("pose", Pose,1)
        self.image_pub = rospy.Publisher("image", Image,1)
        self.bridge = CvBridge()
        self.image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, self.callback, 1)

    def callback(self, data):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "brg8")
            cv_image1 = cv2.resize(cv_image, dsize=(10,10), interpolation=cv2.INTER_AREA)
            gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
            gray1 = cv2.cvtColor(cv_image1, cv2.COLOR_BGR2GRAY)

            
        except CvBridgeError as e:
            print(e)

        (rows, cols, channels) = cv_image.shape
        if cols > 60 and row > 60 :
            cv2.circle(cv_image, (50,50), 10, 255)

        cv2.imshow("Image window", cv_image)
        cv2.waitKey(3)

        try:
            self.image_pub.publish(self.bridge.cv2_to_imgmsg(cv_image, "brg8"))
        except CvBridgeError as e:
            print(e)

def main(args):
    ic = image_converter()
    rospy.init_node('image_converter', anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt :
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)

