#include "ros/ros.h"
#include "std_msgs/Int16.h"

int main(int argc, char **argv){
    ros::init(argc, argv, "motor_pub");
    ros::NodeHandle nh;

    ros::Publisher arduino_pub = nh.advertise<std_msgs::Int16>("motor_msg", 100);
    ros::Rate loop_rate(40);
    std_msgs::Int16 count;
   
    int num = 0;
    int state = 0;
    
    while(ros::ok()){
        ///home/poweron/catkin_ws/src/robot_arm/src/arm.cpp
        for(num = 0; num<180; num++){
            count.data = num;
            arduino_pub.publish(count);
            loop_rate.sleep();
        }
        for(num = 180; num>=0; num--){
            count.data = num;
            arduino_pub.publish(count);
            loop_rate.sleep();
        }
        // if(num<180 && state == 0){
        //     num = num + 1;
        // }
        // else if(num>=180 && state == 0){
        //     state = 1;
        //     num = num - 1;
        // }
        // else if(num<=180 && state == 1){
        //     num = num - 1;
        // }
        // else if(num<=0 && state == 1){
        //     state = 0;
        // }
        
        
        
    }

    return 0;
}
