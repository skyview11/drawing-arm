#include <iostream>
#include "ros/ros.h"
#include "std_msgs/Int16.h"
#include "geometry_msgs/Point.h"
using namespace std;

int main(int argc, char **argv){
    ros::init(argc, argv, "arm");
    ros::NodeHandle nh;

    ros::Publisher robot_arm = nh.advertise<geometry_msgs::Point>("point", 100);
    ros::Rate loop_rate(1);
    geometry_msgs::Point point;
    int call;


    while(ros::ok()){
        cout << "Enter the X_position : ";
        cin >> point.x;
        cout << "Enter the Y_position : ";
        cin >> point.y;
        cout << "Enter the Z_position : ";
        cin >> point.z;

        cout << "Do you want to move your Robot arm? (y == 1/n == 2)" << endl;
        cin >> call;
        switch(call){
            case 1:
                robot_arm.publish(point);
            default:
                break;
        }
        loop_rate.sleep();

    }
}