#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Point
import pyautogui
from pynput import keyboard

pyautogui.PAUSE = 1
## pyautogui.FAILSAFE True

def on_press(key):
    global z
    if key == keyboard.Key.space:
        z = -0.5
    else:
        z = 0.0

def Position():
    global z
    z = 0.0
    pub = rospy.Publisher('/mouse_position', Point, queue_size = 10)
    rospy.init_node('mouse_postion', anonymous = True)

    rate = rospy.Rate(50)
    with keyboard.Listener(on_press=on_press) as listener:
        while not rospy.is_shutdown():
            x, y = get_mouse_position()
            mouse_position_msg = Point()
            mouse_position_msg.x = x
            mouse_position_msg.y = y
            mouse_position_msg.z = z
            
            pub.publish(mouse_position_msg)
            rate.sleep()

def get_mouse_position():
    x, y = pyautogui.position()
    return x, y


if __name__ == '__main__':
    try:
        Position()
    except rospy.ROSInterruptException:
        pass

