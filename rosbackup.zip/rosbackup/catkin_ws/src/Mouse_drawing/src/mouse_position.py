#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Point
import pyautogui
import keyboard
from threading import Timer
import cv2



# def on_press(key):
#     print('key %s pressed' %key)
#     if key == keyboard.Key.space:
#         global z
#         z = -5.0
#     return False  

# def detect_space():
#     def on_press(key):
#         try:
#             if key.char == ' ':
#                 z = -5.0
#         except:
#                 z = 0.0
        

# def on_release(key):
#     global z
#     z = 0.0
#     return False
#     # if key == keyboard.Key.esc:
#     #     return False




pyautogui.PAUSE = 1
## pyautogui.FAILSAFE True


def Position():
    pub = rospy.Publisher('/mouse_position', Point, queue_size = 10)
    rospy.init_node('mouse_postion', anonymous = True)

    rate = rospy.Rate(50)
    while not rospy.is_shutdown():
    
    
        # with keyboard.Listener(on_press=on_press) as listener:
        #     Timer(0.1, listener.stop).start()
        #     listener.join()
            
        
        x, y = get_mouse_position()
        mouse_position_msg = Point()
        mouse_position_msg.x = x
        mouse_position_msg.y = y
        
        if keyboard.is_pressed(' '):
            mouse_position_msg.z = -5.0
        else:
            mouse_position_msg.z = 0.0
        
        
	
        # if keyboard.read_key() == "space":
        #     mouse_position_msg.z = -5.0
        # else:
        #     mouse_position_msg.z = 0.0

        pub.publish(mouse_position_msg)
        rate.sleep()

def get_mouse_position():
    x, y = pyautogui.position()
    return x, y


if __name__ == '__main__':
    try:
        Position()
    except rospy.ROSInterruptException:
        pass



